
import Foundation
import FirebaseDatabase
import UIKit

class TaskController
{
    var tasks = [ToDoTask]()
    var ref = Database.database().reference()
    
    func getTasks() -> [ToDoTask]
    {
        ref.child("Tasks").getData { Error, Data in
            
            guard let data = Data else{
               print(Error!.localizedDescription)
                return
            }
            
            if data.exists()
            {
                let v = data.value
                for (_,val) in v as! NSDictionary{
                    let value = val as! NSDictionary
                    self.tasks.append(
                        ToDoTask(taskId: value["taskId"] as! String,
                                 taskTitle: value["taskTitle"] as! String, dueDate: value["dueDate"]as! String, details: value["details"]as! String, isComplete: value["isComplete"]as! Bool))
                }
            }
        }
        return tasks
        
    }
    func create(task : ToDoTask ) -> String
    {
        var Msg : String = ""
        ref.child("Tasks").child(task.taskId).setValue(task.toDictionary()) { Error, Dataref in
            
            if Error != nil {
                Msg =  Error!.localizedDescription
            }else
            {
                Msg = "Task Added Successfully"
            }
        }
        return Msg
    }
    
    func edit( pTask : ToDoTask) -> String
    {
        var Msg : String = ""
        ref.child("Tasks").child(pTask.taskId).setValue(pTask.toDictionary()) { Error, Dataref in
            
            if Error != nil {
                Msg =  Error!.localizedDescription
            }else
            {
                Msg = "Task Updated Successfully"
            }
        }
        return Msg
    }
    func delete(taskId : String) -> String
    {
        var Msg : String = ""
        ref.child("Tasks").child(taskId).removeValue(completionBlock: {  Error, Dataref in
            
            if Error != nil {
                Msg =  Error!.localizedDescription
            }else
            {
                Msg = "Task Deleted Successfully"
            }
        })
        return Msg
        
    }
    func getNewId() -> String
    {
            let Id = UUID.init().uuidString
            return Id
    }
   
}
