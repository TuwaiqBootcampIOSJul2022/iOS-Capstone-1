
import Foundation
import UIKit

class ToDoTask
{
    var taskId : String
    var taskTitle : String
    var dueDate : String
    var details : String
    var isComplete : Bool
  
    
    public init(taskId : String , taskTitle : String , dueDate : String , details : String , isComplete : Bool)
    {
        self.taskId = taskId
        self.taskTitle = taskTitle
        self.dueDate = dueDate
        self.details = details
        self.isComplete = isComplete
    }
    
    func toDictionary() -> Any
    {
        return [
            "taskId":self.taskId,
            "taskTitle" : self.taskTitle,
            "dueDate": self.dueDate,
            "details" : self.details,
            "isComplete" : self.isComplete
        ]  as Any
    }
    
}

