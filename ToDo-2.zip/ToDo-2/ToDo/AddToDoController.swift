
import UIKit

class AddToDoController: UIViewController {

    @IBOutlet weak var addTitle: UITextField!
    
    @IBOutlet weak var details: UITextField!
    @IBOutlet weak var dueDate: UITextField!
    var controller = TaskController()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dueDate.datePicker(target: self,
                                  doneAction: #selector(doneAction),
                                  cancelAction: #selector(cancelAction),
                                  datePickerMode: .date)
       
    }


    @IBAction func btnSave(_ sender: Any) {
        
        if addTitle.text!.isEmpty || dueDate.text!.isEmpty || details.text!.isEmpty
        {
            showAlert(title: "Error!", Msg: "Fields can not be empty!")
        }else
        {
            let model = ToDoTask(taskId: controller.getNewId(), taskTitle: addTitle.text!, dueDate: dueDate.text!, details: details.text!, isComplete: false)
           let result =  controller.create(task: model)
           
            //self.showAlert(title: "Attention", Msg: result)
            self.dismiss(animated: true, completion: nil)
        }
        
       
    }
   
    @objc
    func cancelAction() {
        self.dueDate.resignFirstResponder()
    }

    @objc
    func doneAction() {
        if let datePickerView = self.dueDate.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let dateString = dateFormatter.string(from: datePickerView.date)
            self.dueDate.text = dateString
            
            self.dueDate.resignFirstResponder()
        }
    }
}
extension UITextField {
    func datePicker<T>(target: T,
                       doneAction: Selector,
                       cancelAction: Selector,
                       datePickerMode: UIDatePicker.Mode = .date) {
        let screenWidth = UIScreen.main.bounds.width
        func buttonItem(withSystemItemStyle style: UIBarButtonItem.SystemItem) -> UIBarButtonItem {
            let buttonTarget = style == .flexibleSpace ? nil : target
            let action: Selector? = {
                switch style {
                case .cancel:
                    return cancelAction
                case .done:
                    return doneAction
                default:
                    return nil
                }
            }()
            
            let barButtonItem = UIBarButtonItem(barButtonSystemItem: style,
                                                target: buttonTarget,
                                                action: action)
            
            return barButtonItem
        }
        let datePicker = UIDatePicker(frame: CGRect(x: 0,
                                                    y: 0,
                                                    width: screenWidth,
                                                    height: 216))
        datePicker.datePickerMode = datePickerMode
        self.inputView = datePicker
        let toolBar = UIToolbar(frame: CGRect(x: 0,
                                              y: 0,
                                              width: screenWidth,
                                              height: 44))
        toolBar.setItems([buttonItem(withSystemItemStyle: .cancel),
                          buttonItem(withSystemItemStyle: .flexibleSpace),
                          buttonItem(withSystemItemStyle: .done)],
                         animated: true)
        toolBar.sizeToFit()
        self.inputAccessoryView = toolBar
    }
}

extension UIViewController
{
    func showAlert(title : String,Msg : String)
    {
        let alert = UIAlertController(title: title, message: Msg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
