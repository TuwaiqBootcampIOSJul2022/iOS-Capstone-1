
import UIKit
import FirebaseDatabase
class ListToDoController: UIViewController {
    var ref = Database.database().reference()
   
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    let controller = TaskController()
    var tasks = [ToDoTask]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // to connect custom cell with tableview
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        imageView.image = UIImage(named: "1.jpg")
       getData()
    }
    
    @IBAction func btn_tapped(_ sender: Any) {
        
       
       
    }
    func getData()
    {
        ref.child("Tasks").observe(.value, with: { data in
            self.tasks.removeAll()
            if data.exists()
            {
                let v = data.value
                for (_,val) in v as! NSDictionary{
                    let value = val as! NSDictionary
                    self.tasks.append(
                        ToDoTask(taskId: value["taskId"] as! String,
                                 taskTitle: value["taskTitle"] as! String, dueDate: value["dueDate"]as! String, details: value["details"]as! String, isComplete: value["isComplete"]as! Bool))
                }
                self.tableView.reloadData()
            }
        })
                                   
    }

}


extension ListToDoController : UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        
        cell.lblDate.text = self.tasks[indexPath.row].dueDate
        cell.lblTitle.text = self.tasks[indexPath.row].taskTitle
        cell.lblDetails.text = self.tasks[indexPath.row].details
        
        return cell
    }

   
}

extension ListToDoController : UITableViewDelegate
{
    // useed to move cell from right to left and delete task
    func tableView(
       _ tableView: UITableView,
       trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath
   ) -> UISwipeActionsConfiguration?
   {
       let actionDelete = UIContextualAction.init(style: .normal, title: "Delete") { _,_,_ in
          // to remove task from database
         let msg = self.controller.delete(taskId: self.tasks[indexPath.row].taskId)
           self.showAlert(title: "Information", Msg: msg)
           // to clear all rasks from array
           self.tasks.removeAll()
           // func to fill array after update database
           self.getData()
       }
       actionDelete.backgroundColor = UIColor.systemRed
       let configuration = UISwipeActionsConfiguration(actions: [actionDelete])
           configuration.performsFirstActionWithFullSwipe = false
           return configuration
   }

    
   // from left to right to edit task
   func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
   {
       let actionEdit = UIContextualAction.init(style: .normal, title: "Edit") { _, _, _ in
         guard  let EditController = self.storyboard?.instantiateViewController(withIdentifier: "EditTask") as? EditToDoController else
         {
             return
         }
           EditController.model = self.tasks[indexPath.row]
           EditController.modalPresentationStyle = .fullScreen
           self.present(EditController, animated: true, completion: nil)
       }
       actionEdit.backgroundColor = UIColor.systemBlue
       let configuration = UISwipeActionsConfiguration(actions: [actionEdit])
           configuration.performsFirstActionWithFullSwipe = false
           return configuration
   }
}
