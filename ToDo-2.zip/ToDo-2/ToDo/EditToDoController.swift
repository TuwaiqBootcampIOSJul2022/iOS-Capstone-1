

import UIKit

class EditToDoController: UIViewController {

    let controller = TaskController()
    @IBOutlet weak var tfDetails: UITextField!
    @IBOutlet weak var tfDate: UITextField!
    @IBOutlet weak var tfTitle: UITextField!
    var model : ToDoTask!
    override func viewDidLoad() {
        super.viewDidLoad()

        if model != nil {
            tfDate.text = model.dueDate
            tfTitle.text = model.taskTitle
            tfDetails.text = model.details
        }
   
    }
    @IBAction func btnSave(_ sender: Any) {
        model.details = tfDetails.text!
        model.taskTitle = tfTitle.text!
        model.dueDate = tfDate.text!
      let msg =  controller.edit( pTask: model)
      
           //  self.showAlert(title: "Great", Msg: msg)
                self.dismiss(animated: true, completion: nil)
           
       
    }
}
